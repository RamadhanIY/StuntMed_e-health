package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    TextView accels_text, txt_prev, txt_change,final_change;
    ProgressBar probar;

    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private double accCurrentVal;
    private double accPrevVal;

    private static double finalchange;
    private boolean mInitialized;

    private double mLastX,mLastY,mLastZ;

    private double NOISE = 0.0003;

    private SensorEventListener sensorEventListener =  new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            final ArrayList<Double> accln = new ArrayList<>();

            float x = sensorEvent.values[0];
            float y = sensorEvent.values[1];
            float z = sensorEvent.values[2];

            if (!mInitialized) {
                mLastX = x;
                mLastY = y;
                mLastZ = z;

                mInitialized = true;
            } else {
                double deltaX = Math.abs(mLastX - x);
                double deltaY = Math.abs(mLastY - y);
                double deltaZ = Math.abs(mLastZ - z);
                if (deltaX < NOISE) deltaX = (double) 0.0;
                if (deltaY < NOISE) deltaY = (double) 0.0;
                if (deltaZ < NOISE) deltaZ = (double) 0.0;
                mLastX = x;
                mLastY = y;
                mLastZ = z;

                //calculate agar nilai ketiga axis tidak berantakan

                accCurrentVal = Math.sqrt((deltaX * deltaX) + (deltaY * deltaY) + (deltaZ * deltaZ));
                accln.add(accCurrentVal);

                double accChangeVal = Math.abs(accCurrentVal - accPrevVal);
                accPrevVal = accCurrentVal;

//            if(accChangeVal != 0){
//                finalchange = accChangeVal;
//            }

                //Update text
                accels_text.setText("Current = " + Math.round(accCurrentVal * 100.0) / 100.0);
                txt_prev.setText("Previous = " + Math.round(accPrevVal * 100.0) / 100.0);
                txt_change.setText("Change " + Math.round(accChangeVal * 100.0) / 100.0);
                final_change.setText("test" + accln);

                probar.setProgress((int) accChangeVal);


            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        accels_text =  findViewById(R.id.accels_text);
        txt_change = findViewById(R.id.txt_change);
        txt_prev = findViewById(R.id.txt_prev);
        final_change = findViewById(R.id.final_change);
        probar = findViewById(R.id.probar);

        //Sensor
        mSensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);

    }
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(sensorEventListener, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(sensorEventListener);
    }
}